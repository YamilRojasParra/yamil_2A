/*
 * Class Output
 *
 * Copyright (c) 2022-2023 UV. All Rights Reserved.
 */
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Clase para crear un archivo de texto 
 * donde se muestraran los resultados del conteo.
 *
 * @version 1.0 06 junio 2022
 * @author yamil rojas 
 */
public class Output {

    public Output() {
    }

    /**
     * @param OutFile 
     * @param outText
     */

    public void writeData(String outFile, String outText) {
	
        BufferedWriter output = null;
        
        try 
    
            {
        
                File file = new File(outFile);
                output = new BufferedWriter(new FileWriter(file));
                output.write(outText);
                output.close();
            } 
    
        catch ( IOException e ) 
    
            {
                e.printStackTrace();
            }   
        }
}
