/*
 * Class App
 * @author yamil
 *
 * Copyright (c) 2022-2023 UV. All Rights Reserved.
 */

/**
 * Clase para inicializar el programa.
 *
 * @version 1.0 06 junio 2022
 * @author yamil rojas
 */
public class App {

    public App() {
        
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
        Logic myLogic = new Logic();
        myLogic.logic2a();
    }

}
